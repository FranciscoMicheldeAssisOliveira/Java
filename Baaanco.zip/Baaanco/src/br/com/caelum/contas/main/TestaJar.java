package br.com.caelum.contas.main;

import br.com.caelum.javafx.api.main.OlaMundo;

public class TestaJar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OlaMundo.main(args);

	}

}
